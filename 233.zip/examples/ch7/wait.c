/*wait.c*/
#include <conio.h>
#include <unistd.h>
#include <dsensor.h>
#include <dlcd.h>

/*
 * we must take the argument, 
 * but we don't have to use it
 */

wakeup_t touch_wakeup(wakeup_t ignore)
{
  return(TOUCH_1);
}

int main(int argc, char *argv[]) 
{
  /*a message from the robot*/
  cputs("touch");
  msleep(500);
  cputs("me");

  /*the event itself*/
  wait_event(touch_wakeup, 0);

  /*we are done*/
  cputs("yay");
  sleep(1);
  /*return to the OS*/
  cls();
  return 0;
}
