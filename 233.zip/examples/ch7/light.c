/*light.c*/
#include <unistd.h>
#include <conio.h>
#include <dsensor.h>

int main(int argc, char **argv) 
{
  /*Turn on the sensor*/
  ds_active(&SENSOR_2);

  while(1)
    {
      /*test to see if it is dark out*/
      if(LIGHT_2<150)
        {
          cputs("dark");
          msleep(10);
        }
      /*if not, say exactly how bright it is*/
      else
        {
          lcd_int(LIGHT_2);
          msleep(10);
        }
    }

  /*go back to the OS*/
  cls();
  return 0;
}
