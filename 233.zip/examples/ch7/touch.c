/*touch.c*/
#include <unistd.h>
#include <conio.h>
#include <dsensor.h>

/*make our man wave hello*/

int main(int argc, char **argv)
{
  while(1)
    {
      /*when we are touching the button, wave*/
      if(TOUCH_1)
        {
          dlcd_show(LCD_ARMS);
        }

      /*if we aren't, don't*/
      else
        {
          dlcd_hide(LCD_ARMS);
        }
    }
  return 0;
}
