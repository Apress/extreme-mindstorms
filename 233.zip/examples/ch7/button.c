/*button.c*/

#include <unistd.h>
#include <conio.h>
#include <dlcd.h>
#include <dsensor.h>
#include <dbutton.h>
#include <dkey.h>

int main(int argc, char **argv) 
{
  int temp;

  /*wait until program is pressed*/
  while(RELEASED(dbutton(),BUTTON_PROGRAM))
    {
      cputs("prog");
    }
  cls();
  sleep(1);

  /*now wait until view is pressed*/
  while(RELEASED(dbutton(),BUTTON_VIEW))
    {
      cputs("view");
    }
  cls();
  sleep(1);

  /*wait until any button is pressed*/
  temp = getchar();

  /*show us which one got pressed*/
  if(8==temp)
    {
      cputs("prog");
    }
  else
    {
      cputs("view");
    }
  sleep(1);
  cls();

  return 0;
}
