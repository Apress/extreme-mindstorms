/* lcd.c */
#include <unistd.h>
#include <conio.h>

int main(int argc, char **argv) 
{
  int k;
  /*make our man wave hello*/
  for(k=0;k<=5;k++)
    {
      cls();
      dlcd_show(LCD_ARMS);
      msleep(200);
      dlcd_hide(LCD_ARMS);
      msleep(200);
    }

  /*now he says hello*/
  cputs("hello");
  msleep(1000);

  /*now he says it differently*/
  /*notice: not too differently*/
  cputs("HELLO");
  msleep(1000);
  cls();

  return 0;
}
