/* seeker.c*/

#include <conio.h>
#include <stdlib.h>
#include <unistd.h>
#include <dsensor.h>
#include <dmotor.h>
#include <dlcd.h>
#include <time.h>

#define BUMPER !TOUCH_1
#define EYE LIGHT_2
#define HISTORY_SIZE 100
#define MAX_COMMAND 2
#define LOCATE_COMMAND 1

/*global process IDs*/
pid_t driving_thread;
pid_t bumper_thread; 
pid_t light_thread;

/*A small array to record history*/
int local_history[10];

/*big history*/
int room_history[HISTORY_SIZE];

/*other useful universal variables*/
/*this is poor form but more reliable*/
long int threshhold = 0;
long int local_average = 0;

/*next turn direction*/
char next_direction;

/*dummy variable*/
wakeup_t dummy = 0;

/* 
 *   bumper press functions
 */

wakeup_t bumper_hit_wakeup(wakeup_t data)
{
  return BUMPER;
}
 
wakeup_t bumper_release_wakeup(wakeup_t data)
{
  return BUMPER;
}

wakeup_t threshhold_wakeup(wakeup_t data)
{
  return(EYE>threshhold);
}

/*
 * Big block of motor commands
 * provides simple functions to cleanup later code.
 */

void run_motors()
{
  motor_a_speed(MAX_SPEED);
  motor_c_speed(MAX_SPEED);
}

void go_forward()
{
  motor_a_dir(fwd);
  motor_c_dir(fwd);
  run_motors();
}

void go_back()
{
  motor_a_dir(rev);
  motor_c_dir(rev);
  run_motors();
}

void spin_left()
{
  next_direction = 'r';
  motor_a_dir(fwd);
  motor_c_dir(rev);
  run_motors();
}

void spin_right()
{
  next_direction = 'l';
  motor_a_dir(rev);
  motor_c_dir(fwd);
  run_motors();
}

void stop_motors()
{
  motor_a_speed(0);
  motor_c_speed(0);
  motor_a_dir(brake);
  motor_c_dir(brake);
}

void change_direction()
{
  /*judging from next direction, turn*/
  if('l'==next_direction)
    {
      spin_left();
    }
  else
    {
      spin_right();
    }
}

/*this finds the index of the largest integer in the array*/
int query_array(int an_array[], int query_type)
{
  int k = 0;
  int max_value = 0;
  int max_index = 0;
  for(k=0;k<HISTORY_SIZE;k++)
    {
      if(an_array[k]>max_value)
        {
          max_value = an_array[k];
          max_index = k;
        }
    }

  /*if we want to get the location of the max*/
  if(LOCATE_COMMAND==query_type)
    {
      return max_index;
    }

  /*if we want to get the value of the max*/
  else
    {
      return max_value;
    }
}

/*move old values down, insert old value at 0*/
void local_history_update(int new_entry)
{
  int k = 0;
  for(k=9;k>0;k--)
    {
      local_history[k]=local_history[k-1];
    }
  local_history[0]=new_entry;
  return;
}

/*get the average of the array*/
int local_history_average()
{
  int total = 0;
  int k = 0;
  for(k=0;k<10;k++)
    {
      total+=local_history[k];
    }
  return (total/10);
}

/*
 * Here we record history and find the brightest spot.
 * Once found, we try to return to it..
 */

void history_calibration()
{
  int initial_max = 0;
  int k = 0;

  /*status report*/
  cputs("calib");
  msleep(100);

  /*here we spin for 3 seconds, taking light readings.*/
  spin_left();
  for(k=0;k<HISTORY_SIZE;k++)
    {
      room_history[k] = EYE;
      msleep(30);
    }
  stop_motors();

  /*find roughly where we found the brightest spot*/

  initial_max = query_array(room_history, MAX_COMMAND); 
  
  lcd_int(initial_max);
  msleep(100);

  /*set the threshhold to a reasonable fraction of the max value*/
  threshhold = (initial_max*85)/100;

  spin_right();

  /*test to see if the local values are ~= max value*/

  wait_event(&threshhold_wakeup, dummy);

  /*We've found it, so let's announce that.*/
  stop_motors();
  cputs("found");
  sleep(1);

  /*what exactly did we find, anyway?*/
  lcd_int(threshhold);
  sleep(1);
  
  return;
}


/*
 * This function drives the motor by default.
 * Should be killed when another thread wants to take control.
 * Simple strategy:
 * If we are getting brighter or staying the same, we are OK.
 * Otherwise, we should sweep back and forth until we find a bright
 * spot again.
 */

int basic_driver(int argc, char *argv[])
{
  time_t sweep_start_time, current_sweep_length;
  int bright_spot_not_found;
  
  go_forward();
  
  while(1)
    {
      /*check the rolling average of readings*/
      local_average = local_history_average();

      /*are we getting brighter?*/
      if(EYE>=local_average)
        {
          lcd_int(local_average);
          local_history_update(EYE);
        } 

      /*uh-oh, we just got darker*/
      /*lets sweep back and forth*/
      else
        {
          stop_motors();

          /*get a new threshhold*/              
          threshhold = local_average;
          
          /*we haven't found anything yet*/
          bright_spot_not_found = 1;

          /*initialize the length of the sweep to 1/10 second*/
          /*remember, it doubles each time, so it grows quickly*/
          current_sweep_length = 100;
          
          while(bright_spot_not_found)
            {
              /*prepare to do a scan*/
              cputs("scan");

              /*what time did we start at?*/
              sweep_start_time = sys_time;

              /*that last try didn't work, let's sweep the other way*/
              change_direction();
                            
              /*sweep left or right for current_sweep_length ms*/
              while(sys_time < (sweep_start_time + current_sweep_length))
                {
                  /*test to see if we are bright enough*/
                  if(threshhold_wakeup(dummy))
                    {
                      /*we found it!*/
                      cputs("found");
                      bright_spot_not_found = 0;
                      break;
                    }
                }
              /*haven't found it, double the length of time we go back*/
              current_sweep_length *= 2;
              /*also, we'll reduce the threshhold by 10%*/
              threshhold *= 90;
              threshhold /= 100;
            }
          /*ok, so we've found the spot. Let's go.*/
          go_forward();
        }
      /*wait some time before sampling again*/
      msleep(100);
    }

  /*so the compiler doesn't complain*/
  return 0;
}

/*
 * This thread tests for the bumper and 
 * takes control of the robot when that occurs.
 */

int bumper_driver(int argc, char *argv[])
{
  while(1)
    {
      wait_event(&bumper_hit_wakeup, dummy);
      
      /*we've hit something. Better stop moving.*/
      kill(driving_thread);
      stop_motors();
      
      lcd_clear();
      cputs("BUMP");

      /*let's back up a little bit*/
      go_back();
      msleep(500);
      
      /*pick a direction*/
      if(random()&(0x1))
        {     
          spin_left();
        }
      else
        {
          spin_right();
        }
      /*wait to spin a reasonable distance*/
      msleep(250);
      
      /*now lets press forward again*/
      go_forward();
      msleep(250);
      stop_motors();

      /*restart the light seeking.*/
      driving_thread = execi(&basic_driver,0,0,PRIO_NORMAL,
                             DEFAULT_STACK_SIZE);
    }
  
  /*so the compiler doesn't complain*/
  return 0;
}

int main(int argc, char *argv[]) 
{
  /*initialize the light sensor*/
  ds_active(&SENSOR_2);

  /*initialize the random number generator*/
  srandom(LIGHT_2);

  /*initialize history and try to orient ourselves*/
  history_calibration();

  /*start the control threads*/
  
  driving_thread = execi(&basic_driver,0,0,PRIO_NORMAL,
                        DEFAULT_STACK_SIZE);
  bumper_thread = execi(&bumper_driver,0,0,PRIO_NORMAL+1,
                        DEFAULT_STACK_SIZE);

  return 0; 
}
