/* rotation.c */

#include <conio.h>
#include <unistd.h>
#include <dsensor.h>
/*
 * main
 */

int main(int argc, char **argv) 
{
  /* turn it on */
  ds_active(&SENSOR_2);
  ds_rotation_on(&SENSOR_2);

  /* calibrate it to 0 */
  ds_rotation_set(&SENSOR_2,0);
  msleep(100);

  while(1)
    {
      lcd_int(ROTATION_2);
      msleep(20);
    }
}
